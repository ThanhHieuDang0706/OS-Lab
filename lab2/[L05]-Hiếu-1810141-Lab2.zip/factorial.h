// factorial.h
#ifndef FACTORIAL_H
#define FACTORIAL_H

char* factorial(const int aNumber);

#endif
